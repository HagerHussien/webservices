# nusoap
NuSoap PHP library

Copy of original library for supporting newer PHP versions
tested on PHP 7
More info at project webite http://nusoap.sourceforge.net/